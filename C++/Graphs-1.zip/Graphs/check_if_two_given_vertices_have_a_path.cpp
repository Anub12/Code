// coding simplified 10th vid in graph playlist.
// do it for both directed and undirected graph.